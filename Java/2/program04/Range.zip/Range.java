
public class Range {

	private double min;
	private double max;
	

public Range()
{
 min=max=0.0;
}
public Range(double min, double max)
{
	this.min=min;
	this.max=max;
}
public double getMin()
{
	 return this.min;
}
public double getMax()
{
	return this.max;
}
public void setMin(double min)
{
	this.min=min;
}
public void setMax(double max)
{
	this.max=max;
}
public boolean overlaps(Range r1, Range r2)
{
		if (r2.getMin()<=r1.getMax() && r2.getMin()>=r1.getMin())
	{
		return true;
	}
	else if (r1.getMax() >= r2.getMin() && r1.getMax()<= r2.getMax() )
	{
		return true;
	}
	else
	{
		return false;
	}
	
}
public boolean contains(double x)
{
	if (x>= min && x<= max)
	{
		return true;
	}
	else
	{
		return false;
	}
}
public boolean rcontains(Range r2)
{
	if(r2.getMin()>= this.getMax() && r2.getMax()<= this.getMax() )
	{
		return true;
	}
	else
return false;
}
public Range combineWith(Range r1, Range r2)
{
	Range r3= new Range();
	if(overlaps(r1, r2) == false )
	{
		return null;
	}
	if ( r1.getMin() <= r2.getMin())
	{	
		r3.setMin(r1.getMin());
		

	}
	else if(r1.getMin() >= r2.getMin())
	{
		r3.setMin(r2.getMin());
		
	}
	if(r1.getMax() >= r2.getMax())
	{
		r3.setMax(r1.getMax());
		System.out.println(r3.getMax());

	}
	else if(r1.getMax() <= r2.getMax())
	{
		r3.setMax(r2.getMax());
		System.out.println(r3.getMax());


	}
	return r3;
	
	
}
public boolean equals( Range r2 )
{
	if (this.getMin()==r2.getMin() && this.getMax()==r2.getMax())
	{
		return true;
	}
	else
	{
		return false;
	}
}
public String toString()
{
	return "(" + this.min + "," + this.max + ")";
}
}