import java.util.*;

public class RangeDriver {
	public static void main(String[] args) {
		Range r1 = new Range();
		Scanner josh = new Scanner(System.in);
		System.out
				.println("Initializing Range entry and testing of constructors \n");
		System.out.println("Enter min and max value for Range 1: ");
		r1.setMin(josh.nextDouble());
		r1.setMax(josh.nextDouble());
		System.out.println("Range 1 changed by setRange" + r1.toString());
		Range r2 = new Range();
		System.out.println("Created Range 2 with default constructor: "
				+ r2.toString());
		System.out.println("Enter new max for Range 2: ");
		r2.setMax(josh.nextDouble());
		System.out.println("Range 2 changed by setMax(): " + r2.toString());
		System.out.println("Enter new min for Range 2: ");
		r2.setMin(josh.nextDouble());
		System.out.println("Range 2 changed by setMin(): " + r2.toString());
		System.out.println("Enter new min and max for Range 2: ");
		r2.setMin(josh.nextDouble());
		r2.setMax(josh.nextDouble());
		System.out.println("Range 2 changed by setRange(): " + r2.toString()
				+ "\n");
		System.out.println("Ending Range entry and testing of constructors \n");
		System.out.println("Starting overlap and containment testing... \n");
		System.out.println("Enter value X for containment testing: ");
		double x = josh.nextDouble();
		if (r1.contains(x) == true) {
			System.out.println("Range 1 contains X");
		} else {
			System.out.println("Range 1 does not contain X");
		}
		if (r2.contains(x) == true) {
			System.out.println("Range 2 contains X");
		} else {
			System.out.println("Range 2 does not contain X");
		}

		System.out.println("Starting combine and equality testing... \n");

		Range r3 = new Range();
		

		r3 = r3.combineWith(r1, r2);
		if (r3 == null) {
			System.out.println("Range 3= Range 1 combined with Range 2: null");

		}
		Range r4 = new Range();
		System.out.println(r4.toString());

		r4 = r4.combineWith(r2, r1);
		
		if (r4 == null) {
			System.out.println("Range 4= Range 2 combined with Range 1: null");

		} else {

			System.out.println("Range 3= Range 1 combined with Range 2: "
					+ r3.toString());
			System.out.println("Range 4= Range 2 combined with Range 1: "
					+ r4.toString());
		}
		if (r1.equals(r2) == false) {
			System.out.println("Range 1 and Range 2 are not equal");
		} else {
			System.out.println("Range 1 and Range 2 are equal");
		}
		System.out.println("\n Ending combine and equality testing");
		System.out.println("Goodbye");

	}

}
